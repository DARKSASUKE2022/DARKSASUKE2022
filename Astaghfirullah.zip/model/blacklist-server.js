const mongo = require('mongoose');

const Schema = mongo.Schema({
  Server: String,
});

module.exports = mongo.model('blacklist-server', Schema)