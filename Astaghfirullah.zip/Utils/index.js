module.exports = {
	logger: require('./Logger'),
};