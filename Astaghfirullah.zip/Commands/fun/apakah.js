const Discord = module.require("discord.js");

module.exports = {
  name: "apakah",
  description: "Kasih Pertanyaan",
  run: async (client, message, args) => {
    if (args.length == 0)
      return message.channel
        .send(`*Usage: Ghost apakah <msg>*`)
        .then((msg) =>setTimeout(() => msg.delete(), 2300));
    
    var fortunes = [
      "Iyasih",
      "Mungking",
      "Gatau Ihhh..",
      "Fih Nga gituu",
      "Hmm..",
    ];
    await message.channel.send(
      fortunes[Math.floor(Math.random() * fortunes.length)]
    );
  },
};
