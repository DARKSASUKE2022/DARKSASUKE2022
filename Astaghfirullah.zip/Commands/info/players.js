const fetch = require("node-fetch")
const { Client, MessageEmbed, Message} = require("discord.js")
const color = require("../../config.json").color;
const moment = require("moment");

module.exports = {
    name: 'player',
    aliases: ["players"],
    description: 'Get info Player Samp',
    
    run: async (client, message, args, prefix) => {
      
      if (!args[0]) return message.channel.send(`**Please enter  **\`ip\`**:**\`port\` __***Repeat***__  __***Command***__  __***>players***__`);
      

      const split = args.join(" ").split(":");
const ip = split[0];
const port = split[1];

       const json = await fetch(`http://anabellebot.online/API/sampquery?ip=${ip}&port=${port}`).then(r => r.json())
        if (json.response === "Something Went Wrong Please Check ip And port correcly or Please Try Again Later") {
  const em = new MessageEmbed()
.setTitle(`**__${ip}:${port}__**`)
.setDescription(`Server is offline!`)
         .setColor(message.guild.me.displayHexColor)
return message.reply({ embeds: [em]});
        }

      if (json.response.isPlayersIngame > 10) return;
        
        const embed = new MessageEmbed()
            .setTitle(`${json.response.hostname}`)
          .setThumbnail(client.user.displayAvatarURL())
          .addField(`${json.response.isPlayerOnline} >> **Players Online**`, `\`\`\`[ID] | Name Players |Score| Ping\n${json.response.isPlayersIngame || "Too Many Players!"}\`\`\``)
          
          .setFooter(message.author.tag, message.author.displayAvatarURL({dynamic:true}))
          .setTimestamp()
            .setColor(message.guild.me.displayHexColor)
        message.channel.send({embeds: [embed]})
      
    }
} 
