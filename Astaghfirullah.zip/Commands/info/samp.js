const fetch = require("node-fetch")
const { Client, MessageEmbed, Message} = require("discord.js")
const color = require("../../config.json").color;
const moment = require("moment");

module.exports = {
    name: 'samp',
    aliases: ["Samp"],
    description: 'Get info Samp',
    
    run: async (client, message, args, prefix) => {
      
      if (!args[0]) return message.channel.send(`**Please enter  **\`ip\`**:**\`port\` __***Repeat***__  __***Command***__  __***>samp***__`);
      

      const split = args.join(" ").split(":");
const ip = split[0];
const port = split[1];

       const json = await fetch(`http://anabellebot.online/API/sampquery?ip=${ip}&port=${port}`).then(r => r.json())
        if (json.response === "Something Went Wrong Please Check ip And port correcly or Please Try Again Later") {
  const em = new MessageEmbed()
.setTitle(`**__${ip}:${port}__**`)
.setDescription(`Server Is Offline!`)
         .setColor(message.guild.me.displayHexColor)
return message.reply({ embeds: [em]});
        }

      if (json.response.isPlayersIngame > 10) return;
      
      var pw = {
            "true": "Enable",
            "false": "Disable"
        };

      
        
        const embed = new MessageEmbed()
            .setTitle(`${json.response.hostname}`)
          .setThumbnail(client.user.displayAvatarURL())
          .addField("**__Gamemode__**", `\`\`\`${json.response.gamemode}\`\`\``)
          .addField("**__Server Ip And Port__**",`\`\`\`${ip}:${port}\`\`\``) 
          .addField("**__Language__**",                   `\`\`\`${json.response.language}\`\`\``)
          .addField("**__Players Online__**", `\`\`\`${json.response.isPlayerOnline}/${json.response.maxplayers}\`\`\``)
          .addField("**__Max Players__**", `\`\`\`${json.response.maxplayers}\`\`\``)
          .addField("**__Map Name__**", `\`\`\`${json.response.rule.mapname}\`\`\``)
          .addField("**__password__**", `\`\`\`${json.response.passworded}\`\`\``)
          .addField("**__Lagcomp__**", `\`\`\`${json.response.rule.lagcomp}\`\`\``)
          .addField("**__Version__**", `\`\`\`${json.response.rule.version}\`\`\``)
          .addField("**__Weather__**", `\`\`\`${json.response.rule.weather}\`\`\``)
          .addField("**__Website__**", `[${json.response.rule.weburl}](https://${json.response.rule.weburl})`)
          .addField(`${json.response.isPlayerOnline} >> **__Players Online__**`, `\`\`\`[ID] | Name | Score | Ping |\n${json.response.isPlayersIngame || "Too Many Players!"}\`\`\``)
          .setFooter(message.author.tag, message.author.displayAvatarURL({dynamic:true}))
          .setTimestamp()
            .setColor(message.guild.me.displayHexColor)
        message.channel.send({embeds: [embed]})
    }
        }