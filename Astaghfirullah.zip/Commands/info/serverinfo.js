const moment = require('moment');
const {
  MessageEmbed
} = require('discord.js');

module.exports = {
  name: 'serverinfo',
  aliases: ['si'],
  cooldowns: 10,
  description: 'Show Info Server',
  run: async(client, msg, args) => {
    //Boost 
    var boost;
    if(msg.guild.premiumTier === `NONE`){
      boost = `Level 0`;
    }
    if(msg.guild.premiumTier === `TIER_1`){
      boost = `Level 1`;
    }
    if(msg.guild.premiumTier === `TIER_2`){
      boost = `Level 2`;
    }
    if(msg.guild.premiumTier === `TIER_3`){
      boost = `Level 3`;
    }
    //CREATED AT
    const createdAt = moment(msg.guild.createdAt);
    const tanggal = createdAt.format('dddd, DD MMMM YYYY, HH:mm') + '\n_(' + createdAt.fromNow() + ')_';
    //VANITY URL
    var vanity;
    msg.guild.fetchVanityData().then(inv => {
      vanity = inv.code
    }).catch(() => console.error)
    //GUILD OWNER
    const gown = await msg.guild.fetchOwner();
    
    const embed = new MessageEmbed()
    .setAuthor(`${msg.guild.name}`, client.user.displayAvatarURL({
      dynamic: true
    }))
    .addField(`**__Owner:__**`, `${gown.user.tag} _(ID: ${gown.id})_`)
    .addField(`**__ID Server:__**`, `${msg.guild.id}`)
    .addField(`**__Members:__**`, `${msg.guild.memberCount}`)
    .addField(`**__Online Members:__**`, `${msg.guild.members.cache.filter(m => m.presence !== 'offline').size}`)
    .addField(`**__Boost Status__**`, `${msg.guild.premiumSubscriptionCount || '0'} Boost _(${boost})_`)
    .addField(`**__Roles:__**`, `${msg.guild.roles.cache.size}`)
    .addField(`**__Channels:__**`, `${msg.guild.channels.cache.size}`)
    .addField(`**__Text Channels:__**`, `${msg.guild.channels.cache.filter(c => c.type === 'GUILD_TEXT').size}`)
    .addField(`**__Voice Channels:__**`, `${msg.guild.channels.cache.filter(c => c.type === 'GUILD_VOICE').size}`)
    .addField(`**__Category Channels:__**`, `${msg.guild.channels.cache.filter(c => c.type === 'GUILD_CATEGORY').size}`)
    .addField(`**__Verification Level:__**`, `${msg.guild.verificationLevel}`)
    .addField(`**__Created At:__**`, `${tanggal}`)
    .addField(`**__Emojis:__**`, `${msg.guild.emojis.cache.size}`)
    .addField(`**__Vanity Url:__**`, `${vanity ? `https://discord.gg/${vanity}`: `None`}`)
    .setFooter(` ${msg.author.tag}`, msg.author.displayAvatarURL({
      dynamic: true
    }))
    .setThumbnail(msg.guild.iconURL({
      dynamic: true
    }))
    .setColor(msg.guild.me.displayHexColor)
    .setTimestamp()
    msg.reply({ embeds: [embed]});
  }
                             }