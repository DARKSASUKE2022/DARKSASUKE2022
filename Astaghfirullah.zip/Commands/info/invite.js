const {
  MessageEmbed
} = require('discord.js')
module.exports = {
  name: 'invite',
  aliases: ['inv'],
  cooldowns: 5,
  description: 'Send Link Invite Bot',
  run: async(client, msg, args) => {
    const embed = new MessageEmbed()
    .setTitle(`**Invite ${client.user.username}**`)
    .setDescription(`**[Click To Invite Me!](https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=215136&scope=bot)**`)
    .setFooter(`By: ${msg.author.tag}`, msg.author.displayAvatarURL({ dynamic: true}))
    .setTimestamp()
    .setColor(msg.guild.me.displayHexColor)
    msg.channel.send({ embeds: [embed]}).then(msg => {
      setTimeout(() => {
        msg.delete();
      }, 5000);
    });
  }
};