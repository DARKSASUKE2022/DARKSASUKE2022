const {
  MessageEmbed
} = require('discord.js');

const {
  prefix
} = require('../../config.json');
//const os = require('os');
const moment = require('moment');

module.exports = {
  name: 'help',
  aliases: ['helps', 'h'],
  cooldowns: 5,
  description: 'Show info bot',
  run: async(client, msg, args) => {
    require("moment-duration-format");
    
    const help = new MessageEmbed()
    .setThumbnail(client.user.displayAvatarURL({dynamic: true}))
    .addField(`**__🛠️ HELP 🛠️__**`,`\n**__🤖BOT STATS🤖:__**`, `\`\`\`Prefix: ${prefix}\nAll Commands: ${client.commands.size}\`\`\``)
    .addField(`**__📢INFORMATION📢:__**`, `\`\`\`botinfo | invite | snipe | ping\`\`\``)
    .addField(`**__😈BOSS GHOST😈:__**`, `\`\`\`update | serverlist | ddos | nfsw\`\`\``)
    .addField(`**__👤GENERAL👤:__**`, `\`\`\`dm | say\`\`\``)
    .addField(`**__🎮SA-MP🎮:__**`, `\`\`\`samp | players\`\`\``)
    .addField(`**__🔎SEARCH🔎:__**`, `\`\`\`anime | github | gif\`\`\``)
    .addField(`**__🥳FUN🥳:__**`, `\`\`\`hack | apakah | kapan\`\`\``)
    .setFooter(`〢${msg.author.tag}`, msg.author.displayAvatarURL({ dynamic: true }))
    .setTimestamp()
    .setColor(`060101`)
    msg.reply({ embeds: [help]});
  }
}
