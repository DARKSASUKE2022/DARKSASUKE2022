const {
  MessageEmbed
} = require('discord.js');

const {
  prefix
} = require('../../config.json');
//const os = require('os');
const moment = require('moment');

module.exports = {
  name: 'ping',
  aliases: ['pings'],
  cooldowns: 5,
  description: 'Show Info Bot',
  run: async(client, msg, args) => {
    require("moment-duration-format");
    
const ping = new MessageEmbed()
    .setThumbnail(client.user.displayAvatarURL({dynamic: true}))
.addField(`**__🤖 Bot Ping/Latency:__**`, `\`\`\`Ping: ${msg.client.ws.ping} ms\`\`\``)
    .setFooter(`〢${msg.author.tag}`, msg.author.displayAvatarURL({ dynamic: true }))
    .setTimestamp()
    .setColor(`060101`)
    msg.reply({ embeds: [ping]});
  }
}
