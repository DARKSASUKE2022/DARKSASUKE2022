const { MessageEmbed } = require("discord.js");

module.exports = {
  name: 'dm',
  aliases: ['pm','DM'],
  run: async (client, message, args) => {
    let total = args[0];
    if(!total) {
      let e = new MessageEmbed()
      .setColor(message.guild.me.displayHexColor)
      .setDescription("Gunakan: `>dm <Seseorang> <Pesan>`");
      return message.reply({ embeds: [e] })
    };
let user = message.mentions.users.first();
if(!user) return;
let apa = message.content.split(" ").slice(2).join(" ");
if(!apa) return;
user.send({ content: `
**GHOST SA-MP DM**

${apa}

From: **${message.author.tag}**
` });
message.delete()
  }
                            }